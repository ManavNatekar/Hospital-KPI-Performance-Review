# Hospital KPI Performance Review

**Synthetic portfolio case study.** All records, patients, doctors, events and hospital names are fictional. Do not present as real hospital data.

## Contents
- `data/`: cleaned OPD, admissions, lab, billing, trusted admissions analysis and row-level cleaning log
- `notebooks/hospital_kpi_analysis.ipynb`: Python analysis notebook
- `outputs/hospital_kpi_dashboard.xlsx`: KPI scorecard and segment dashboard
- `outputs/*.csv`: KPI summaries and profiling extracts
- `outputs/*.png`: eight charts
- `reports/Hospital_KPI_Project_Report.docx`: project report
- `reports/Hospital_KPI_Insight_Deck.pptx`: eight-slide deck

## Row counts
OPD 240,000 | Admissions 80,000 | Labs 130,000 | Billing 50,000 | Total 500,000

## KPI definitions
- Average LOS: mean discharge date minus admission date, minimum one day.
- Occupancy: occupied bed-days / available bed-days, based on monthly interval overlap and fictional bed capacities.
- 30-day readmission proxy: next admission for same patient within 0–30 days after discharge.

Open the notebook from the `notebooks/` folder. Packages: pandas, numpy, matplotlib.

Additional outputs: matched month-of-year 2024 vs 2025 comparison; department/doctor LOS deciles; patient utilization cohorts.
